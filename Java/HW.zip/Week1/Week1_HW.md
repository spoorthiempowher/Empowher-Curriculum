#Week1 home work

You are part of a team tasked with creating an application for managing college operations. Your assignment includes the following tasks:
1) Identifying different objects.
2) Defining classes.
3) Determining class attributes.
4) Specifying class operations.
5) Identifying and categorizing relationships between classes using 'is a', 'has a', and 'part of'.

As part of solution you dont need to create actual java classes, just provide solution explaining above in plain english.